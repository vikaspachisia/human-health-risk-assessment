module.exports = {
  secret: "hhra-secret-key"
};
